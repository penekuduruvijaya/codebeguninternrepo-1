import java.util.Scanner;

public class SimpleCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Simple Calculator\n1. Addition\n2. Subtraction\n3. Multiplication\n4. Division");
        System.out.print("Enter your choice (1-4): ");
        int choice = scanner.nextInt();

        System.out.print("Enter two numbers: ");
        double num1 = scanner.nextDouble(), num2 = scanner.nextDouble();

        System.out.println("Result: " + (choice == 1 ? num1 + num2 : choice == 2 ? num1 - num2 : choice == 3 ? num1 * num2 : choice == 4 && num2 != 0 ? num1 / num2 : "Invalid or division by zero"));

        scanner.close();
    }
}