import java.util.Scanner;

public class CountWords {

    
    public static int countWords(String str) {
       
        String[] words = str.trim().split("\\s+");

        
        return words.length;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

       
        int wordCount = countWords(input);
        System.out.println("The number of words in the string is: " + wordCount);

        scanner.close();
    }
}